#!/bin/sh

# Disable Debain APT repo
[ -z "$(grep -o '# deb' /etc/apt/sources.list.d/debian.list)" ] && sed -i "s/deb /# deb /g" /etc/apt/sources.list.d/debain.list
