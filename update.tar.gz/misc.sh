#!/bin/bash

systemctl enable swap.service
systemctl enable apt-fix.service
