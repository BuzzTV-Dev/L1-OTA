#!/bin/bash

systemctl enable swap.service
