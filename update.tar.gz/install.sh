#!/bin/bash

otaDir="/tmp/.ota/update"

# Install bootloader
if [ -f "$otaDir/images/uboot.img" ]; then
	ubootPart="/dev/mmcblk2p1"
	[ -L "/dev/disk/by-partlabel/uboot" ] && ubootPart="/dev/disk/by-partlabel/uboot"
	dd if=$otaDir/images/uboot.img of=$ubootPart
fi

# Install kernel
if [ -f "$otaDir/images/boot.img" ]; then
	bootPart="/dev/mmcblk2p3"
	[ -L "/dev/disk/by-partlabel/boot" ] && bootPart="/dev/disk/by-partlabel/boot"
	dd if=$otaDir/images/boot.img of=$bootPart
fi

# Install files
cp -rf $otaDir/files/* /
[ -d "$otaDir/files/home/user" ] && chown user:user -R /home/user/

# Execute misc script
[ -f "$otaDir/misc.sh" ] && sh $otaDir/misc.sh

# Finish update
depmod -a 2>/dev/null
